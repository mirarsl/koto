package com.yasagames.koto

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
